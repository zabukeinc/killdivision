

<?php $__env->startSection('title'); ?>
    <title>CART - KILLDIVISION</title>
<?php $__env->stopSection(); ?>
<div class="container">
    <div class="row" style="padding:50px;">
    <div class="col-12 col-md-12 col-lg-12 ml-lg-auto">
<div class="order-details-confirmation">

    <div class="cart-page-heading">
        <h5>Your Order</h5>
        <p>The Details</p>
    </div>

    <ul class="order-details-form mb-4">
        <li><span>Product</span> <span>Total</span></li>
        <?php $__empty_1 = true; $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <li>
            <span><?php echo e($row['product_name']); ?> (<?php echo e($row['qty']); ?>x)</span>
            <span>Rp. <?php echo number_format($row['product_price'], 0, ',', '.'); ?></span>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <li>
            <h4>Cart is empty</h4>
        </li>
        <li><span>Total</span> <span><?php echo e($carts['product_price'] * $carts['qty']); ?></span></li>
        <?php endif; ?>
        <br><br>
        <li><span>Subtotal</span> <span>Rp. <?php echo number_format($subtotal, 0, ',', '.'); ?></span></li>
    </ul>
    <a href="#" class="btn essence-btn">Place Order</a>
</div>
</div>
    </div>
</div>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miftah Regyana\Desktop\works\bobskuy\kdivision\resources\views/ecommerce/cart.blade.php ENDPATH**/ ?>