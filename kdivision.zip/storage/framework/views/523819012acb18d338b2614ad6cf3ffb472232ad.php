

<?php $__env->startSection('title'); ?>
    <title>Tambah Chapter</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Chapter</li>
        <li class="breadcrumb-item active">Add Chapter</li>

    </ol>
    <div class="container-fluid">
        <div class="animated fadeIn">

            <form action="<?php echo e(route('chapter.store')); ?>" method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Tambah Chapter</h4>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="name">Chapter Name</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                                    <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="name">Chapter Name</label>
                                    <textarea name="description" id="description" cols="30" rows="10"><?php echo e(old('description')); ?></textarea>
                                    <p class="text-danger"><?php echo e($errors->first('description')); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="image">Foto Chapter</label>
                                    <input type="file" name="image" class="form-control" value="<?php echo e(old('image')); ?>" required>
                                    <p class="text-danger"><?php echo e($errors->first('image')); ?></p>
                                     <button class="btn btn-primary btn-sm">Tambah</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<!-- PADA ADMIN LAYOUTS, TERDAPAT YIELD JS YANG BERARTI KITA BISA MEMBUAT SECTION JS UNTUK MENAMBAHKAN SCRIPT JS JIKA DIPERLUKAN -->
<?php $__env->startSection('js'); ?>
    <!-- LOAD CKEDITOR -->
    <script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>
    <script>
        //TERAPKAN CKEDITOR PADA TEXTAREA DENGAN ID DESCRIPTION
        CKEDITOR.replace('description');
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miftah Regyana\Desktop\works\bobskuy\kdivision\resources\views/chapters/create.blade.php ENDPATH**/ ?>