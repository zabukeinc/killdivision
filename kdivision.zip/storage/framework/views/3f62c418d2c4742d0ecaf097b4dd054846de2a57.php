

<?php $__env->startSection('title'); ?>
    <title>KILLDIVISION - CO</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ##### Shop Grid Area Start ##### -->
    <section class="shop_grid_area section-padding-80">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8 col-lg-9">
                    <div class="shop_grid_product_area">
                        <div class="row">
                            <div class="col-12">
                                <div class="product-topbar d-flex align-items-center justify-content-between">
                                    <!-- Total Products -->
                                    <div class="total-products">
                                        <p><span><?php echo e(count($result)); ?></span> products found</p>
                                    </div>
                                    <!-- Sorting -->
                                    <!-- <div class="product-sorting d-flex">
                                        <p>Sort by:</p>
                                        <form action="#" method="get">
                                            <select name="select" id="sortByselect">
                                                <option value="value">Highest Rated</option>
                                                <option value="value">Newest</option>
                                                <option value="value">Price: $$ - $</option>
                                                <option value="value">Price: $ - $$</option>
                                            </select>
                                            <input type="submit" class="d-none" value="">
                                        </form>
                                    </div> -->
                                </div>
                            </div>
                        </div>

                        <div class="row">

                        <?php $__empty_1 = true; $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <!-- Single Product -->
                            <div class="col-12 col-sm-6 col-lg-4">
                                <div class="single-product-wrapper">
                                    <!-- Product Image -->
                                    <div class="product-img">
                                        <img src="<?php echo e(asset('storage/products/' . $row->thumbnail)); ?>" alt="<?php echo e($row->name); ?>">
                                        <!-- Hover Thumb -->
                                        <img class="hover-img" src="<?php echo e(asset('storage/products/' . $row->thumbnail)); ?>" alt="<?php echo e($row->name); ?>" alt="">

                                        <!-- Product Badge -->
                                        <!-- <div class="product-badge offer-badge">
                                            <span>-30%</span>
                                        </div> -->
                                    </div>

                                    <!-- Product Description -->
                                    <div class="product-description">
                                        <a href="<?php echo e(url('product/' . $row->slug)); ?>">
                                            <h6><?php echo e($row->name); ?></h6>
                                        </a>
                                        <p class="product-price"> Rp. <?php echo number_format($row->price, 0, ',', '.'); ?></p>

                                        <!-- <form action="<?php echo e(route('front.cart')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                        <div class="hover-content">
                                            <input type="hidden" name="product_id" value="<?php echo e($row->id); ?>" class="form-control">
                                            <div class="add-to-cart-btn">
                                                <button class="btn essence-btn">Add to Cart</button>
                                            </div>
                                        </div>
                                        </form> -->
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-md-12 text-center" style="margin:0 auto;">
                                <h3>Produk tidak ditemukan</h3>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- Pagination -->
                    <nav aria-label="navigation">
                        <ul class="pagination mt-50 mb-70">
                        <?php echo e($result->links()); ?>

                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miftah Regyana\Desktop\works\bobskuy\kdivision\resources\views/ecommerce/product-result.blade.php ENDPATH**/ ?>