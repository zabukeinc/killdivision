

<?php $__env->startSection('title'); ?>
    <title>Jual <?php echo e($product->name); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="single_product_details_area d-flex align-items-center">

    <!-- Single Product Thumb -->
    <!-- <div class="single_product_thumb clearfix">
    <img src="<?php echo e(asset('storage/products/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
    </div> -->
    <!-- Single Product Thumb -->
    <div class="single_product_thumb clearfix">
        <div class="product_thumbnail_slides owl-carousel">
        <?php $__empty_1 = true; $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <img src="<?php echo e(asset('storage/products/' . $img->filename)); ?>" alt="image">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
        </div>
    </div>

    <!-- Single Product Description -->


    <div class="single_product_desc clearfix">
        <a href="<?php echo e(url('/category/' . $product->category->slug)); ?>"><span><?php echo e($product->category->name); ?></span></a>
            <h2><?php echo e($product->name); ?></h2>
        <p class="product-price">Rp. <?php echo number_format($product->price, 0, ',', '.'); ?></p>
        <p class="product-desc"><?php echo $product->description; ?></p>

        <!-- Form -->
        <form action="<?php echo e(route('front.cart')); ?>" method="POST">
            <!-- Select Box -->
            <div class="select-box d-flex mt-50 mb-30">
                <select name="product_size" id="product_size" class="mr-5">
                    <option value="XL">Size: XL</option>
                    <option value="L">Size: L</option>
                    <option value="M">Size: M</option>
                    <option value="S">Size: S</option>
                </select>
                    <hp style="margin-top:15px;margin-right:5px;">Qty</hp>
                    <input type="number" min="1" class="form-control" name="qty" id="qty" default="1" style="width:20%;text-align:center;" value="1">
            </div>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" class="form-control">
            <div class="cart-fav-box d-flex align-items-center">
                <!-- Cart -->
                <button class="btn essence-btn">Add to cart</button>
            </div>
            </form>
    </div>
</section>


<script>
function increaseQty() {
    var value = parseInt(document.getElementById('qty').value, 10);
    value = isNaN(value) ? 0 : value;
    value++;
    document.getElementById('qty').value = value;
}

function decreaseQty(){
    var value = parseInt(document.getElementById('qty').value, 10);
    value = isNaN(value) ? 0 : value;
    value <= 1 ? value = 1 : '';
    value--;
    document.getElementById('qty').value = value;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miftah Regyana\Desktop\works\bobskuy\kdivision\resources\views/ecommerce/show.blade.php ENDPATH**/ ?>