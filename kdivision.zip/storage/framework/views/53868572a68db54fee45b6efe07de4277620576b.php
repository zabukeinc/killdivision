<ul>
    <li><a href="<?php echo e(url('shop')); ?>">Shop</a>
    </li>
    <li><a href="#">Chapter</a>
        <ul class="dropdown">
        <?php $__currentLoopData = $chapter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(url('/chapter/' . $chapter->slug)); ?>"><?php echo e($chapter->name); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </li>
    <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
    <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
</ul><?php /**PATH C:\Users\Miftah Regyana\Desktop\works\bobskuy\kdivision\resources\views/layouts/ecommerce/module/menu.blade.php ENDPATH**/ ?>