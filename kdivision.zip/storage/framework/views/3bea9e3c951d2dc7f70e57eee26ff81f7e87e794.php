

<?php $__env->startSection('title'); ?>
    <title>KILLDIVISION - CO</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php $__empty_1 = true; $__currentLoopData = $home; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<img src="<?php echo e(asset('storage/home/' . $row->image)); ?>">
<section class="welcome_area">
        <div class="container text-center">
            <div class="row h-100 align-items-center">
                <div class="col-12">
                    <div class="hero-content">
                        <h6><?php echo e($row->subtitle); ?></h6>
                        <h2><?php echo e($row->title); ?></h2>
                        <a href="<?php echo e(url('shop')); ?>" class="btn essence-btn">SHOP NOW</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ecommerce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miftah Regyana\Desktop\works\bobskuy\kdivision\resources\views/ecommerce/index.blade.php ENDPATH**/ ?>