

<?php $__env->startSection('title'); ?>
    <title>Edit Chapter</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main class="main">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">Chapter</li>
        <li class="breadcrumb-item active">Edit Chapter</li>
    </ol>
    <div class="container-fluid">
        <div class="animated fadeIn">

          	<!-- PASTIKAN MENGIRIMKAN ID PADA ROUTE YANG DIGUNAKAN -->
            <form action="<?php echo e(route('chapter.update', $chapters->id)); ?>" method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
              	<!-- KARENA UPDATE MAKA KITA GUNAKAN DIRECTIVE DIBAWAH INI -->
                <?php echo method_field('PUT'); ?>
              	<!-- FORM INI SAMA DENGAN CREATE, YANG BERBEDA HANYA ADA TAMBAHKAN VALUE UNTUK MASING-MASING INPUTAN  -->
                <div class="row">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Edit Chapter</h4>
                            </div>
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="name">Name</label>
                                    <input type="text" name="name" class="form-control" value="<?php echo e($chapters->name); ?>" required>
                                    <p class="text-danger"><?php echo e($errors->first('name')); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="name">Chapter Description</label>
                                    <textarea name="description" id="description" cols="30" rows="10"><?php echo e($chapters->description); ?></textarea>
                                    <p class="text-danger"><?php echo e($errors->first('description')); ?></p>
                                </div>
                                <div class="form-group">
                                    <label for="image">Foto Chapter</label>
                                    <br>
                                  	<!--  TAMPILKAN GAMBAR SAAT INI -->
                                    <img src="<?php echo e(asset('storage/chapters/' . $chapters->image)); ?>" width="100px" height="100px" alt="<?php echo e($chapters->name); ?>">
                                    <hr>
                                    <input type="file" name="image" class="form-control">
                                    <p><strong><i>ABAIKAN JIKA TIDAK INGIN MENGGANTI GAMBAR</i></strong></p>
                                    <p class="text-danger"><?php echo e($errors->first('image')); ?></p>
                                    <button class="btn btn-primary btn-sm">Update</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- LOAD CKEDITOR -->
    <script src="https://cdn.ckeditor.com/4.13.0/standard/ckeditor.js"></script>
    <script>
        //TERAPKAN CKEDITOR PADA TEXTAREA DENGAN ID DESCRIPTION
        CKEDITOR.replace('description');
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Miftah Regyana\Desktop\works\bobskuy\kdivision\resources\views/chapters/edit.blade.php ENDPATH**/ ?>