<?php

heder("Location:public/");